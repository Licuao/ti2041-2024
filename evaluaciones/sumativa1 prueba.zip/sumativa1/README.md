# TI2041 - Programación Back-End
### Instalación de Django

<code>**python -m pip install Django==5.1.1**</code>

<code>**py -m pip install Django==5.1.1**</code>
<br>
1.- obligatorio instalar python 
<br>
2.- crear el proyecto en un terminal con "django-admin startproject" "nombre del proyecto"
<br>
3.- crear el modulo app en una terminal "python ./manage.py startapp "nombre del modulo""
<br>
4.- iniciar el servidor desde la carpeta de el proyecto con "python .\manage.py runserver"
